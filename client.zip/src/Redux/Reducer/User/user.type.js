export const GET_USER = "GET_USER";
export const AUTH_USER = "AUTH_USER";
export const SELF = "SELF";
export const CLEAR_USER = "CLEAR_USER";